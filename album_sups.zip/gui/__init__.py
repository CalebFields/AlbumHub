# Standard library imports
import tkinter as tk
from tkinter import ttk

class GUI:
    def __init__(self, parent, root):
        # Initialization methods
        self.initialize_app(root)
        self.setup_ui()
        self.connect_db()
    
    def setup_theme(self): 
        """Configure dark mode theme for the application"""
        self.dark_bg = "#2E2E2E"
        self.light_fg = "#FFFFFF"
        self.button_bg = "#444444"
        self.button_fg = "#FFFFFF"
        self.header_bg = "#3C3F41"
        self.treeview_bg = "#333333"
        self.entry_bg = "#444444"
        self.select_bg = "#4A6984"
        self.select_fg = "#FFFFFF"
        
        self.root.configure(bg=self.dark_bg)
        
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Configure widget styles
        self.configure_widget_styles()
        
    def create_tabs(self): ...

# gui/import_tab.py
class ImportTab:
    def setup_import_tab(self): 
        """Create the import and processing tab"""
        self.import_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.import_tab, text='Import Data')
        
        # Main frame
        main_frame = ttk.Frame(self.import_tab, style='TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Instructions section
        self.setup_instructions_section(main_frame)
        
        # File selection section
        self.setup_file_selection_section(main_frame)
        
        # Status section
        self.setup_status_section(main_frame)
        
        # Action buttons
        self.setup_action_buttons(main_frame)
        
        # Log output
        self.setup_log_output(main_frame)

    def setup_file_selection(self):
        """Set up the file selection section"""
        file_frame = ttk.Frame(parent, style='TFrame')
        file_frame.pack(fill=tk.X, pady=(0, 20))
        
        self.file_path_var = tk.StringVar()
        ttk.Label(file_frame, text="Selected file:", style='TLabel').pack(side=tk.LEFT, padx=5)
        ttk.Entry(file_frame, textvariable=self.file_path_var, width=50, style='TEntry').pack(side=tk.LEFT, padx=5)
        ttk.Button(file_frame, text="Browse...", command=self.select_input_file).pack(side=tk.LEFT, padx=5)

    def setup_progress_display(self):
        """Set up progress display"""
        progress_frame = ttk.Frame(parent, style='TFrame')
        progress_frame.pack(fill=tk.X, pady=(0, 10))

        self.progress_var = tk.StringVar()
        self.progress_var.set("Ready to start ranking")
        ttk.Label(
            progress_frame, 
            textvariable=self.progress_var,
            style='TLabel'
        ).pack(side=tk.LEFT)

        self.progress_bar = ttk.Progressbar(
            progress_frame,
            orient=tk.HORIZONTAL,
            mode='determinate'
        )
        self.progress_bar.pack(side=tk.RIGHT, fill=tk.X, expand=True)

# gui/browser_tab.py 
class BrowserTab:
    def setup_browser_tab(self): 
        """Set up the browser tab"""
        browser_tab = ttk.Frame(self.notebook)
        self.notebook.add(browser_tab, text="Browse Collection")
        
        main_frame = ttk.Frame(browser_tab, style='TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.setup_search_filter_section(main_frame)
        self.setup_results_treeview(main_frame)

    def setup_search_filters(self): 
        """Set up the search and filter section with dropdowns"""
        # Create a frame to hold the controls
        control_frame = ttk.Frame(parent)
        control_frame.pack(fill=tk.X, pady=(0, 10))

        # Filter frame for dropdowns
        self.filter_frame = ttk.Frame(control_frame)
        self.filter_frame.pack(side=tk.RIGHT)

        # Label for filters
        ttk.Label(self.filter_frame, text="Filters:").pack(side=tk.LEFT, padx=5)

        # Genre dropdown
        self.genre_var = tk.StringVar(value="All")
        self.genre_menu = tk.OptionMenu(self.filter_frame, self.genre_var, "All", command=self.on_filter)
        self.genre_menu.pack(side=tk.LEFT, padx=5)
        print("Genre dropdown initialized and packed")  # Replace with your logging method

        # Artist dropdown
        self.artist_var = tk.StringVar(value="All")
        self.artist_menu = tk.OptionMenu(self.filter_frame, self.artist_var, "All", command=self.on_filter)
        self.artist_menu.pack(side=tk.LEFT, padx=5)
        print("Artist dropdown initialized and packed")  # Replace with your logging method

        # Force UI refresh
        self.root.update()
        print("Filter section UI refreshed")

    def setup_results_view(self): 
        """Set up the Treeview for displaying album results"""
        tree_frame = ttk.Frame(parent, style='TFrame')
        tree_frame.pack(fill=tk.BOTH, expand=True)

        self.tree = ttk.Treeview(tree_frame, columns=("Artist", "Title", "Year", "Genres"), show="headings", style="Treeview")
        self.tree.heading("Artist", text="Artist")
        self.tree.heading("Title", text="Title")
        self.tree.heading("Year", text="Year")
        self.tree.heading("Genres", text="Genres")
        self.tree.column("Artist", width=200)
        self.tree.column("Title", width=250)
        self.tree.column("Year", width=50)
        self.tree.column("Genres", width=200)

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.log_message("Treeview initialized for album results")

# gui/ranker_tab.py
class RankerTab:
    def setup_ranker_tab(self): 
        """Initialize the ranking tab with proper error handling"""
        try:
            self.ranker_tab = ttk.Frame(self.notebook)
            self.notebook.add(self.ranker_tab, text='Album Ranker')

            # Main frame
            main_frame = ttk.Frame(self.ranker_tab, style='TFrame')
            main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

            # Game state variables - initialize with defaults
            self.album_graph = {}
            self.comparison_queue = []
            self.known_pairs = set()
            self.sorted_albums = []
            self.comparison_count = 0
            self.current_pair = []
            self.album_rankings = {}
            self.current_filter = None

            # UI elements
            self.setup_ranker_controls(main_frame)
            self.setup_filter_controls(main_frame)
            self.setup_comparison_interface(main_frame)
            self.setup_progress_display(main_frame)

            # Initialize with empty data
            self.reset_ranking_state()

            # Load albums when tab is selected
            self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

    def setup_comparison_interface(self): 
        """Set up the album comparison UI"""
        compare_frame = ttk.LabelFrame(parent, text="Which album do you prefer?", style='TFrame')
        compare_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 20))

        # Album display frames
        self.album1_frame = ttk.Frame(compare_frame, style='TFrame')
        self.album1_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.album2_frame = ttk.Frame(compare_frame, style='TFrame')
        self.album2_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Album 1 elements
        self.album1_image = ttk.Label(self.album1_frame)
        self.album1_image.pack(pady=10)

        self.album1_info = ttk.Label(
            self.album1_frame, 
            text="Album 1 info will appear here",
            style='TLabel',
            wraplength=300
        )
        self.album1_info.pack(pady=10)

        self.choose_album1 = ttk.Button(
            self.album1_frame,
            text="Choose This Album",
            command=lambda: self.record_choice(0),
            state=tk.DISABLED
        )
        self.choose_album1.pack(pady=10)

        # Album 2 elements
        self.album2_image = ttk.Label(self.album2_frame)
        self.album2_image.pack(pady=10)

        self.album2_info = ttk.Label(
            self.album2_frame, 
            text="Album 2 info will appear here",
            style='TLabel',
            wraplength=300
        )
        self.album2_info.pack(pady=10)

        self.choose_album2 = ttk.Button(
            self.album2_frame,
            text="Choose This Album",
            command=lambda: self.record_choice(1),
            state=tk.DISABLED
        )
        self.choose_album2.pack(pady=10)

    def update_ranking_display(self): ...